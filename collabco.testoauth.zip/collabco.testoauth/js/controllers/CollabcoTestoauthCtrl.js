(function () {
  'use strict';

  angular
    .module('app.collabco.testoauth')
    .controller('CollabcoTestoauthCtrl', CollabcoTestoauthCtrl);



  function CollabcoTestoauthCtrl () {
    var vm = this;
    vm.view = "Template Application";
  }

})();
