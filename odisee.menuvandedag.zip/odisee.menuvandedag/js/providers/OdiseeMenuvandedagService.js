(function () {
  'use strict';

  angular
    .module('providers.odisee.menuvandedag')
    .service('OdiseeMenuvandedagService', OdiseeMenuvandedagService);



  function OdiseeMenuvandedagService () {

    var self = this;
    
    this.getMenu = function () {
      var deferred = $q.defer();
              
      return $http.get(endpoint)
      .then(function (response) {
          deferred.resolve(response.data);
          return deferred.promise;
      });
    }
  }

})();
