(function () {
  'use strict';

  angular
    .module('app.odisee.menuvandedag', [])
    .config(['$stateProvider', config]);



  function config ($stateProvider) {

    var main = {
      appId: 'odisee.menuvandedag',
      html: 'main',
      controller: 'OdiseeMenuvandedagCtrl as vm',
      abstract: true,
      defaultChild: menu
    };

    var menu = {
      name: "menu",
      url: "/menu/{menuId}",
      html: "menu",
      controller: 'OdiseeMenuvandedagMenuCtrl as vm'
    }

    $stateProvider.appState(main);
    $stateProvider.appState(menu);
  }


})();
